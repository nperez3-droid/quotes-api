<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
  header('Access-Control-Allow-Headers: Origin, Accept, Content-Type');
  exit();
}

include_once '../../config/Database.php';

$db = (new Database())->connect();

switch($method) {

  case 'GET':

    $query = "SELECT q.id, q.quote, a.author, c.category
              FROM quotes q
              JOIN authors a ON q.author_id = a.id
              JOIN categories c ON q.category_id = c.id";

    $conditions = [];
    $params = [];

    if(isset($_GET['id'])) {
      $conditions[] = "q.id=?";
      $params[] = $_GET['id'];
    }
    if(isset($_GET['author_id'])) {
      $conditions[] = "q.author_id=?";
      $params[] = $_GET['author_id'];
    }
    if(isset($_GET['category_id'])) {
      $conditions[] = "q.category_id=?";
      $params[] = $_GET['category_id'];
    }

    if($conditions) {
      $query .= " WHERE " . implode(" AND ", $conditions);
    }

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($data ?: ["message"=>"No Quotes Found"]);
  break;

  case 'POST':
    $data = json_decode(file_get_contents("php://input"));

    if(!empty($data->quote) && !empty($data->author_id) && !empty($data->category_id)) {

      // check author exists
      $check = $db->prepare("SELECT id FROM authors WHERE id=?");
      $check->execute([$data->author_id]);
      if(!$check->fetch()) {
        echo json_encode(["message"=>"author_id Not Found"]);
        exit;
      }

      // check category exists
      $check = $db->prepare("SELECT id FROM categories WHERE id=?");
      $check->execute([$data->category_id]);
      if(!$check->fetch()) {
        echo json_encode(["message"=>"category_id Not Found"]);
        exit;
      }

      $stmt = $db->prepare("INSERT INTO quotes (quote, author_id, category_id) VALUES (?,?,?)");
      $stmt->execute([$data->quote,$data->author_id,$data->category_id]);

      echo json_encode([
        "id"=>$db->lastInsertId(),
        "quote"=>$data->quote,
        "author_id"=>$data->author_id,
        "category_id"=>$data->category_id
      ]);

    } else {
      echo json_encode(["message"=>"Missing Required Parameters"]);
    }
  break;

  case 'PUT':
    $data = json_decode(file_get_contents("php://input"));

    if(!empty($data->id) && !empty($data->quote) && !empty($data->author_id) && !empty($data->category_id)) {

      $stmt = $db->prepare("UPDATE quotes SET quote=?, author_id=?, category_id=? WHERE id=?");
      $stmt->execute([$data->quote,$data->author_id,$data->category_id,$data->id]);

      echo json_encode($data);

    } else {
      echo json_encode(["message"=>"Missing Required Parameters"]);
    }
  break;

  case 'DELETE':
    $data = json_decode(file_get_contents("php://input"));

    if(!empty($data->id)) {
      $stmt = $db->prepare("DELETE FROM quotes WHERE id=?");
      $stmt->execute([$data->id]);
      echo json_encode(["id"=>$data->id]);
    } else {
      echo json_encode(["message"=>"Missing Required Parameters"]);
    }
  break;
}