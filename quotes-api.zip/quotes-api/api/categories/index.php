<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
  header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
  header('Access-Control-Allow-Headers: Origin, Accept, Content-Type');
  exit();
}

include_once '../../config/Database.php';

$db = (new Database())->connect();

switch($method) {

  case 'GET':
    if(isset($_GET['id'])) {
      $stmt = $db->prepare("SELECT * FROM categories WHERE id=?");
      $stmt->execute([$_GET['id']]);
      $data = $stmt->fetch(PDO::FETCH_ASSOC);

      echo json_encode($data ?: ["message"=>"category_id Not Found"]);
    } else {
      $stmt = $db->query("SELECT * FROM categories");
      echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
  break;

  case 'POST':
    $data = json_decode(file_get_contents("php://input"));
    if(!empty($data->category)) {
      $stmt = $db->prepare("INSERT INTO categories (category) VALUES (?)");
      $stmt->execute([$data->category]);
      echo json_encode(["id"=>$db->lastInsertId(),"category"=>$data->category]);
    } else {
      echo json_encode(["message"=>"Missing Required Parameters"]);
    }
  break;

  case 'PUT':
    $data = json_decode(file_get_contents("php://input"));
    if(!empty($data->id) && !empty($data->category)) {
      $stmt = $db->prepare("UPDATE categories SET category=? WHERE id=?");
      $stmt->execute([$data->category,$data->id]);
      echo json_encode(["id"=>$data->id,"category"=>$data->category]);
    } else {
      echo json_encode(["message"=>"Missing Required Parameters"]);
    }
  break;

  case 'DELETE':
    $data = json_decode(file_get_contents("php://input"));
    if(!empty($data->id)) {
      $stmt = $db->prepare("DELETE FROM categories WHERE id=?");
      $stmt->execute([$data->id]);
      echo json_encode(["id"=>$data->id]);
    } else {
      echo json_encode(["message"=>"Missing Required Parameters"]);
    }
  break;
}